import React from 'react';

const Main = () => {
    return (
        <div>
          Главная
        </div>
    );
};

export default Main;